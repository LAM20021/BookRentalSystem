package com.csumb.luism.bookrentalsystem;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class AvailableBooksAdapter extends ArrayAdapter<Book> {

    private int resourceLayout;
    private int selectedItemPosition = -1;

    public AvailableBooksAdapter(Context context, int resource, List<Book> items) {
        super(context, resource, items);
        this.resourceLayout = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;

        if (v == null) {
            LayoutInflater vi;
            vi = LayoutInflater.from(getContext());
            v = vi.inflate(resourceLayout, null);
        }

        Book book = getItem(position);

        if (book != null) {
            TextView titleTextView = v.findViewById(R.id.textViewBookTitle);
            TextView authorTextView = v.findViewById(R.id.textViewBookAuthor);
            TextView feeTextView = v.findViewById(R.id.textViewFeePerDay);

            if (titleTextView != null) {
                titleTextView.setText("Title: " + book.getTitle());
            }

            if (authorTextView != null) {
                authorTextView.setText("Author: " + book.getAuthor());
            }

            if (feeTextView != null) {
                if (feeTextView != null) {
                    String formattedFee = String.format("Fee per Day: $%.2f", book.getFee());
                    feeTextView.setText(formattedFee);
                }
            }

            // Highlight the selected item
            if (position == selectedItemPosition) {
                v.setActivated(true);
            } else {
                v.setActivated(false);
            }
        }

        return v;
    }

    public void setSelectedItemPosition(int position) {
        selectedItemPosition = position;
        notifyDataSetChanged();
    }
}
