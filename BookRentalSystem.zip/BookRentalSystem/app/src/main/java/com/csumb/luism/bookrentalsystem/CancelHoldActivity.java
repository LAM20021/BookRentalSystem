package com.csumb.luism.bookrentalsystem;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.content.Intent;

public class CancelHoldActivity extends AppCompatActivity {

    private Button cancelHoldButton;
    private BookRentalSystemDao bookRentalSystemDao;
    private ListView reservedBooksListView;
    private ReservedBooksAdapter reservedBooksAdapter; // Create an adapter for the ListView

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel_hold);
        bookRentalSystemDao = BookRentalSystemDatabase.getDatabase(this).getBookRentalSystemDao();

        reservedBooksListView = findViewById(R.id.reservedBooksListView);

        reservedBooksAdapter = new ReservedBooksAdapter(this, R.layout.item_reserved_book, new ArrayList<>());
        reservedBooksListView.setAdapter(reservedBooksAdapter);

        reservedBooksListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Book selectedBook = reservedBooksAdapter.getItem(position);

                reservedBooksAdapter.setSelectedItemPosition(position);


                if (selectedBook != null) {
                    String selectedBookTitle = selectedBook.getTitle();
                }
            }
        });

        cancelHoldButton = findViewById(R.id.cancelHoldButton);
        cancelHoldButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedPosition = reservedBooksAdapter.getSelectedItemPosition();
                if (selectedPosition != -1) {
                    Book selectedBook = reservedBooksAdapter.getItem(selectedPosition);
                    if (selectedBook != null) {
                        String selectedBookTitle = selectedBook.getTitle();
                        String pickupDate = getPickupDate(selectedBook.getAvailability());
                        String returnDate = getReturnDate(selectedBook.getAvailability());

                        showCancelConfirmationDialog(selectedBookTitle, pickupDate, returnDate);
                    }
                }
            }
        });

        String customerUsername = getIntent().getStringExtra("customerUsername"); // Replace with actual customer username

        loadReservedBooksForCustomer(customerUsername);

    }

    private void loadReservedBooksForCustomer(String customerUsername) {
        List<Book> reservedBooks = bookRentalSystemDao.getReservedBooksForCustomer(customerUsername);


        if (reservedBooks.isEmpty()) {
            showNoReservationsDialog();
        } else {
            reservedBooksAdapter.clear();
            reservedBooksAdapter.addAll(reservedBooks);
            reservedBooksAdapter.notifyDataSetChanged();
            for (Book book : reservedBooks) {
                char[] availability = book.getAvailability();


            }
        }
    }

    private void showNoReservationsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("No Reservations");
        builder.setMessage("You have no reserved books.");

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                navigateToMainMenu();
            }
        });

        builder.create().show();
    }


    private void navigateToMainMenu() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private String getPickupDate(char[] availability) {
        for (int i = 0; i < availability.length; i++) {
            if (availability[i] == '-') {
                return "December " + (i) + ", 2023";
            }
        }
        return "";
    }

    private String getReturnDate(char[] availability) {
        for (int i = availability.length - 1; i >= 0; i--) {
            if (availability[i] == '-') {
                return "December " + (i) + ", 2023";
            }
        }
        return "";
    }

    private void showCancelConfirmationDialog(final String selectedBookTitle, final String pickupDate, final String returnDate) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Cancel Reservation");
        builder.setMessage("Are you sure you want to cancel the reservation for the book \"" + selectedBookTitle +
                "\" with Pickup Date: " + pickupDate + " and Return Date: " + returnDate + "?");

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                cancelBookAndNavigate(selectedBookTitle, pickupDate, returnDate);
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });

        builder.create().show();
    }

    private void cancelBookAndNavigate(String selectedBookTitle, String pickupDate, String returnDate) {
        String customerUsername = getIntent().getStringExtra("customerUsername");
        bookRentalSystemDao.cancelBookHold(selectedBookTitle, customerUsername);

        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        LogEntry logEntry = new LogEntry("Cancel Hold", "Customer: " + customerUsername +
                ", Book Title: " + selectedBookTitle +
                ", Pickup Date: " + pickupDate +
                ", Return Date: " + returnDate, timestamp  + "\n");
        bookRentalSystemDao.insertLogEntry(logEntry);

        navigateToMainMenu();
    }
}
