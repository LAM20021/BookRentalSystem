package com.csumb.luism.bookrentalsystem;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ReservedBooksAdapter extends ArrayAdapter<Book> {

    private int resourceLayout;
    private int selectedItemPosition = -1; // Initially, no item is selected

    public ReservedBooksAdapter(Context context, int resource, List<Book> items) {
        super(context, resource, items);
        this.resourceLayout = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;

        if (v == null) {
            LayoutInflater vi;
            vi = LayoutInflater.from(getContext());
            v = vi.inflate(resourceLayout, null);
        }

        Book book = getItem(position);

        if (book != null) {
            TextView titleTextView = v.findViewById(R.id.titleTextView);
            TextView pickupDateTextView = v.findViewById(R.id.pickupDateTextView);
            TextView returnDateTextView = v.findViewById(R.id.returnDateTextView);

            if (titleTextView != null) {
                titleTextView.setText(book.getTitle());

            }


            if (pickupDateTextView != null && returnDateTextView != null) {
                char[] availability = book.getAvailability();


                String pickupDate = getPickupDate(availability);
                String returnDate = getReturnDate(availability);

                pickupDateTextView.setText("Pickup Date: " + pickupDate);
                returnDateTextView.setText("Return Date: " + returnDate);
            }


            if (position == selectedItemPosition) {
                v.setActivated(true);
            } else {
                v.setActivated(false);
            }
        }

        return v;
    }


    public void setSelectedItemPosition(int position) {
        selectedItemPosition = position;
        notifyDataSetChanged();
    }

    public int getSelectedItemPosition() {
        return selectedItemPosition;
    }

    private String getPickupDate(char[] availability) {
        for (int i = 0; i < availability.length; i++) {
            if (availability[i] == '-') {
                return "December " + (i) + ", 2023";
            }
        }
        return "";
    }

    private String getReturnDate(char[] availability) {
        for (int i = availability.length - 1; i >= 0; i--) {
            if (availability[i] == '-') {
                return "December " + (i) + ", 2023";
            }
        }
        return "";
    }

}
